import Topiclist from "@/components/TopicList";

export default function Home() {
  return (
   <Topiclist/>
  );
}
